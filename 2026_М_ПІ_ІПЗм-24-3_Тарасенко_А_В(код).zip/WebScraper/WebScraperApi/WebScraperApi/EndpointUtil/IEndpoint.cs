﻿namespace WebScraperApi.EndpointUtil;

public interface IEndpoint
{
    void MapEndpoint(IEndpointRouteBuilder app);
}