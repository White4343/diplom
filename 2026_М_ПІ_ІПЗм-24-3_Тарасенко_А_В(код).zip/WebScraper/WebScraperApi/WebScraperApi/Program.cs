using DeepSeek.ApiClient.Extensions;
using WebScraperApi.EndpointUtil;
using WebScraperApi.Scraper;
using WebScraperApi.Scraper.Claude;
using WebScraperApi.Scraper.DeepSeek;
using WebScraperApi.Scraper.OpenAI;

namespace WebScraperApi;

public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddAuthorization();
        builder.Services.AddEndpointsApiExplorer();

        // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
        builder.Services.AddOpenApi();

        builder.Services.AddHttpClient();

        builder.Services.AddEndpoints();

        builder.Services.AddDeepSeekClient(builder.Configuration["DeepSeekKey"].ToString());

        builder.Services.AddScoped<IClaudeService, ClaudeService>();
        builder.Services.AddScoped<IOpenAIService, OpenAIService>();
        builder.Services.AddScoped<IDeepSeekService, DeepSeekService>();

        builder.Services.AddScoped<ScraperHandler>();

        var app = builder.Build();

        app.UseHttpsRedirection();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.MapOpenApi();
        }

        app.UseHttpsRedirection();
        app.UseSwaggerUI();

        app.UseAuthorization();

        app.MapEndpoints();

        await app.RunAsync().ConfigureAwait(false);
    }
}
