﻿namespace WebScraperApi.Scraper;

public record ScrapperResponse(string Model, string? Result, bool IsSuccess, string? Error = null);