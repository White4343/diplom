﻿using WebScraperApi.Scraper.Claude;
using DeepSeek.ApiClient.Interfaces;
using DeepSeek.ApiClient.Models;

namespace WebScraperApi.Scraper.DeepSeek;

public class DeepSeekService(IConfiguration configuration, ILogger<DeepSeekService> logger, IDeepSeekClient deepSeekClient) : IDeepSeekService
{
    public async Task<ScrapperResponse> GetScrapedResultAsync(string url, string html, string target)
    {
        try
        {
            var key = configuration["DeepSeekKey"];

            var request = new DeepSeekRequestBuilder()
                .SetModel(DeepSeekModel.V3)
                .SetStream(false)
                .SetTemperature(0)
                .SetSystemMessage("You are a web scraping assistant. Extract the requested information from HTML and return it as a JSON array.")
                .AddUserMessage($"Extract the following data from this HTML: {target}. URL: {url}\n\nHTML content:\n{html}");

            string response = await deepSeekClient.SendMessageAsync(request.Build());

            return new ScrapperResponse("DeepSeek", response, true);
        }
        catch (Exception ex)
        {
            return new ScrapperResponse("DeepSeek", null, false, ex.Message);
        }
    }
}