﻿namespace WebScraperApi.Scraper.Claude;

public interface IDeepSeekService
{
    Task<ScrapperResponse> GetScrapedResultAsync(string url, string html, string target);
}