﻿using Claudia;

namespace WebScraperApi.Scraper.Claude;

public class ClaudeService(IConfiguration configuration, ILogger<ClaudeService> logger) : IClaudeService
{
    public async Task<ScrapperResponse> GetScrapedResultAsync(string url, string html, string target)
    {
        try
        {
            var claudeKey = configuration["ClaudeApiKey"];

            var anthropic = new Anthropic
            {
                ApiKey = claudeKey
            };

            var message = await anthropic.Messages.CreateAsync(new()
            {
                Model = "claude-3-7-sonnet-20250219",
                MaxTokens = 1024,
                Messages = [new() { Role = "user", Content = $"Extract the following data from this HTML: {target}. " +
                $"Return results as a JSON array. URL: {url}\n\nHTML content:\n{html}" }]
            });

            return new ScrapperResponse("Claude", message.Content[0].Text, true);
        }
        catch (Exception ex)
        {
            return new ScrapperResponse("Claude", null, false, ex.Message);
        }

    }
}
