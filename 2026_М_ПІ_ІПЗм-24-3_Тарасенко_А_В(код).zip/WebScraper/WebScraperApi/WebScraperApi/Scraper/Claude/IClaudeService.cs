﻿namespace WebScraperApi.Scraper.Claude;

public interface IClaudeService
{
    Task<ScrapperResponse> GetScrapedResultAsync(string url, string html, string target);
}