﻿using WebScraperApi.Scraper.Claude;

namespace WebScraperApi.Scraper;

public class ScraperHandler(IClaudeService claudeService, IOpenAIService openAIService, IDeepSeekService deepSeekService, IHttpClientFactory httpClientFactory)
{
    public async Task<List<ScrapperResponse>> HandleAsync(ScraperCommand scraperCommand) 
    {
        ArgumentNullException.ThrowIfNullOrEmpty(scraperCommand.Target);
        ArgumentNullException.ThrowIfNullOrEmpty(scraperCommand.URL);

        var resultList = new List<ScrapperResponse>();

        var html = await GetHTMLAsync(scraperCommand.URL);

        if (scraperCommand.WantClaude) {
            ScrapperResponse result = await claudeService.GetScrapedResultAsync(scraperCommand.URL, html, scraperCommand.Target);

            resultList.Add(result);
        }

        if (scraperCommand.WantChatGPT)
        {
            ScrapperResponse result = await openAIService.GetScrapedResultAsync(scraperCommand.URL, html, scraperCommand.Target);

            resultList.Add(result);
        }

        if (scraperCommand.WantDeepSeek) {
            ScrapperResponse result = await deepSeekService.GetScrapedResultAsync(scraperCommand.URL, html, scraperCommand.Target);

            resultList.Add(result);
        }        

        return resultList;
    }

    private async Task<string> GetHTMLAsync(string url)
    {
        try
        {
            var httpClient = httpClientFactory.CreateClient();
            var response = await httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            string html = await response.Content.ReadAsStringAsync();

            if (html.Length > 200000)
            {
                html = TrimHtmlContent(html);
            }

            return html;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error fetching webpage: {ex.Message}");
            return string.Empty;
        }
    }

    private string TrimHtmlContent(string html)
    {
        // Implementation to trim HTML content
        try
        {
            // Remove comments
            html = System.Text.RegularExpressions.Regex.Replace(html, "<!--.*?-->", "",
                System.Text.RegularExpressions.RegexOptions.Singleline);

            // Remove scripts
            html = System.Text.RegularExpressions.Regex.Replace(html, "<script.*?</script>", "",
                System.Text.RegularExpressions.RegexOptions.Singleline);

            // Remove styles
            html = System.Text.RegularExpressions.Regex.Replace(html, "<style.*?</style>", "",
                System.Text.RegularExpressions.RegexOptions.Singleline);

            // Remove iframes
            html = System.Text.RegularExpressions.Regex.Replace(html, "<iframe.*?</iframe>", "",
                System.Text.RegularExpressions.RegexOptions.Singleline);

            // Remove SVGs (often large and not essential for scraping text content)
            html = System.Text.RegularExpressions.Regex.Replace(html, "<svg.*?</svg>", "",
                System.Text.RegularExpressions.RegexOptions.Singleline);

            // Remove footer
            html = System.Text.RegularExpressions.Regex.Replace(html, "<footer.*?</footer>", "",
                System.Text.RegularExpressions.RegexOptions.Singleline);

            // If still too large, consider removing navigation, aside, etc.
            if (html.Length > 200000)
            {
                html = System.Text.RegularExpressions.Regex.Replace(html, "<nav.*?</nav>", "",
                    System.Text.RegularExpressions.RegexOptions.Singleline);
                html = System.Text.RegularExpressions.Regex.Replace(html, "<aside.*?</aside>", "",
                    System.Text.RegularExpressions.RegexOptions.Singleline);
            }

            // If still too large, truncate to 200,000 characters
            // but make sure we don't cut in the middle of a tag
            if (html.Length > 200000)
            {
                int cutPoint = 199000;  // Cut a bit before 200k to leave room for closing tags

                // Try to find the last closing tag before our cutoff
                int lastClosingTag = html.LastIndexOf("</", cutPoint);
                if (lastClosingTag > 0)
                {
                    // Find the end of this tag
                    int endOfTag = html.IndexOf(">", lastClosingTag);
                    if (endOfTag > 0 && endOfTag < 200000)
                    {
                        cutPoint = endOfTag + 1;
                    }
                }

                html = html.Substring(0, cutPoint) + "</body></html>";
            }

            return html;
        }
        catch
        {
            // If trimming fails, just truncate to 200k
            if (html.Length > 200000)
            {
                return html.Substring(0, 200000);
            }
            return html;
        }
    }

}
