﻿using WebScraperApi.EndpointUtil;

namespace WebScraperApi.Scraper;

public class ScraperEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPost("/get",
            async (ScraperCommand command, ScraperHandler useCase) =>
                await useCase.HandleAsync(command).ConfigureAwait(false))
            .WithTags("Scraper")
            .WithOpenApi();
    }
}