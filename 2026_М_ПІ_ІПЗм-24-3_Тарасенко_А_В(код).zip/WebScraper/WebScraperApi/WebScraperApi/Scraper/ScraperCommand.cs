﻿namespace WebScraperApi.Scraper;

public record ScraperCommand(string URL, string Target, bool WantClaude, bool WantChatGPT, bool WantDeepSeek);