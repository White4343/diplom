﻿namespace WebScraperApi.Scraper.Claude;

public interface IOpenAIService
{
    Task<ScrapperResponse> GetScrapedResultAsync(string url, string html, string target);
}