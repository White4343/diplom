﻿using System.Text.Json;
using System.Text;
using WebScraperApi.Scraper.Claude;
using OpenAI.Chat;

namespace WebScraperApi.Scraper.OpenAI;

public class OpenAIService(IConfiguration configuration, ILogger<OpenAIService> logger) : IOpenAIService
{
    public async Task<ScrapperResponse> GetScrapedResultAsync(string url, string html, string target)
    {
        try
        {
            var key = configuration["OpenAIKey"];

            ChatClient client = new(model: "gpt-4.1-mini", apiKey: key);

            ChatCompletion completion = await client.CompleteChatAsync($"You are a web scraping assistant. Extract the requested information from HTML and return it as a JSON array.\nExtract the following data from this HTML: {target}. URL: {url}\n\nHTML content:\n{html}");

            return new ScrapperResponse("ChatGPT", completion.Content[0].Text, true);
        }
        catch (Exception ex)
        {
            return new ScrapperResponse("ChatGPT", null, false, ex.Message);
        }
    }
}